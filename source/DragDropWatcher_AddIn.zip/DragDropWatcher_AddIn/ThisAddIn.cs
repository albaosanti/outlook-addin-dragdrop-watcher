﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Microsoft.VisualBasic;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;
using System.Text.RegularExpressions;

using Outlook = Microsoft.Office.Interop.Outlook;
using Office = Microsoft.Office.Core;

namespace DragDrapWatcher_AddIn
{
    public partial class ThisAddIn
    {
        #region private variables
        private Outlook._NameSpace outNS;
        private string profileName = string.Empty;
        private SuperMailFolder folderToWrap;
        private clsSendNotif err_sender;
        #endregion

        #region ClassMailFolder object
        class SuperMailFolder
        {
            #region private variables
            Outlook.Folder _wrappedFolder;
            string _profileName;
            public List<SuperMailFolder> wrappedSubFolders = new List<SuperMailFolder>();
            string folderName = string.Empty;
            private clsSendNotif err_sender = new clsSendNotif();
            #endregion

            #region constructor
            internal SuperMailFolder(Outlook.Folder folder, string profileName)
            {
                try
                {
                    //assign it to local private master
                    _wrappedFolder = folder;
                    folderName = folder.Name;
                    _profileName = profileName;
                    //assign event handlers for the folder
                    _wrappedFolder.Items.ItemAdd += Items_ItemAdd;
                    _wrappedFolder.BeforeItemMove += Before_ItemMoveListener;
                    
                    //Go through all the subfolders and wrap them as well
                    foreach (Outlook.Folder tmpFolder in _wrappedFolder.Folders)
                    {
                        SuperMailFolder tmpWrapFolder = new SuperMailFolder(tmpFolder, _profileName);
                        wrappedSubFolders.Add(tmpWrapFolder);
                        wrappedSubFolders.AddRange(tmpWrapFolder.wrappedSubFolders);
                    }
                }
                catch (Exception ex)
                {err_sender.SendNotification(ex.Message + ex.StackTrace);}
            }
            #endregion

            private void Before_ItemMoveListener(object Item, Outlook.MAPIFolder TargetFolder, ref bool Cancel) 
            {
                try{
                    if (Item is Outlook.MailItem && TargetFolder != null)
                    {
                        string src_rule_name = "";
                        string tar_rule_name = "";

                        bool changed = false;
                        bool eadd_exist = false;
                        
                        Outlook.Rules rules = null;
                        Outlook.MailItem oMsg = (Outlook.MailItem)Item;
                        Outlook.Folder src_folder = (Outlook.Folder)oMsg.Parent;
                        Outlook.Rule src_rule = null;
                        
                        if (string.IsNullOrWhiteSpace(oMsg.SenderEmailAddress)) return; 

                        //REMOVE RULE FROM SOURCE FOLDER
                        if (src_folder.Name.ToLower() != "inbox" && 
                                src_folder.Name.ToLower().StartsWith(Properties.Settings.Default.WatchFolder_Prefix.ToLower()))
                        {
                            src_rule_name = Properties.Settings.Default.RuleName_Prefix + src_folder.Name;
                            rules = Globals.ThisAddIn.Application.Session.DefaultStore.GetRules();
                                                   
                            foreach (Outlook.Rule rule in rules)
                            {
                                if (rule.Name.ToLower() == src_rule_name.ToLower())
                                {
                                    src_rule = rule;
                                    foreach (Outlook.Recipient rc in rule.Conditions.From.Recipients)
                                    {
                                        if (rc.Address.ToLower() == oMsg.SenderEmailAddress.ToLower())
                                        {
                                            rc.Delete();
                                            rc.Resolve();
                                            changed = true;
                                            //MessageBox.Show("An rule from " + oMsg.SenderEmailAddress + " has been deleted!", "AddIn DragDrop");
                                            break;
                                        }
                                    }
                                    break;
                                }
                            }
                            if (src_rule != null)
                            {
                                if (src_rule.Conditions.From.Recipients.Count == 0)
                                    rules.Remove(src_rule_name);
                            }
                        }

                        //DESTINATION FOLDER
                        if(TargetFolder.Name.ToLower() !="inbox" && 
                                TargetFolder.Name.ToLower().StartsWith( Properties.Settings.Default.WatchFolder_Prefix.ToLower())){
                            
                            tar_rule_name = Properties.Settings.Default.RuleName_Prefix + TargetFolder.Name;
                            Outlook.Rule tar_rule = null;

                            if (rules == null) 
                                    rules = Globals.ThisAddIn.Application.Session.DefaultStore.GetRules();
                            
                            //FIND RULE
                            foreach (Outlook.Rule rule in rules)
                            {
                                if (rule.Name.ToLower() == tar_rule_name.ToLower())
                                {
                                    tar_rule = rule;
                                    break;
                                }
                            }
                                                 
                            if (tar_rule == null)
                            {
                                //CREATE NEW RULE
                                tar_rule = rules.Create(tar_rule_name, Outlook.OlRuleType.olRuleReceive);
                                //MOVE TO
                                tar_rule.Actions.MoveToFolder.Folder = (TargetFolder);
                                tar_rule.Actions.MoveToFolder.Enabled = true;
                            }

                            //Check if Email Already Exist
                            if (tar_rule.Conditions.From.Recipients.Count > 0)
                            {
                                foreach (Outlook.Recipient rec in tar_rule.Conditions.From.Recipients)
                                {
                                    if (rec.Address.ToLower() == oMsg.SenderEmailAddress.ToLower())
                                    {
                                        eadd_exist = true;
                                        break;
                                    }
                                }
                            }

                            //ADD FROM EMAIL
                            if (!eadd_exist)
                            {                               
                                tar_rule.Conditions.From.Recipients.Add(oMsg.SenderEmailAddress);
                                tar_rule.Conditions.From.Recipients.ResolveAll();
                                tar_rule.Conditions.From.Enabled = true;
                            }
                            changed = true;
                        }  

                        //Save rules
                        if (rules != null && changed) rules.Save(true);
                    }
                }catch(Exception ex){
                    err_sender.SendNotification(ex.Message + ex.StackTrace);
                }                               
            }

            void Items_ItemRemove()
            {
            }

            #region Handler of addition item into a folder
            void Items_ItemAdd(object Item)
            {
                try
                {
                    if (Item is Outlook.Folder)
                    {
                        SuperMailFolder tmpWrapFolder = new SuperMailFolder((Outlook.Folder) Item, _profileName);
                        wrappedSubFolders.Add(tmpWrapFolder);
                        wrappedSubFolders.AddRange(tmpWrapFolder.wrappedSubFolders);
                    }
                }
                catch (Exception ex)
                {
                    err_sender.SendNotification(ex.Message + ex.StackTrace);
                }
            }

            #endregion
        }
        #endregion

        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {   
            err_sender = new clsSendNotif();
            try
            {
                Outlook.Application application = this.Application;
                //Get the MAPI namespace
                outNS = application.GetNamespace("MAPI");
                //Get UserName
                string profileName = outNS.CurrentUser.Name;

                //DRAG & DROP WILL BE CREATED HERE
                Outlook.Folders folders = outNS.Folders;
                if (folders.Count > 0)
                {
                    foreach (Outlook.Folder fldr in folders) 
                        folderToWrap = new SuperMailFolder(fldr, profileName);                       
                }
                
            }
            catch (Exception ex)
            {err_sender.SendNotification(ex.Message + ex.StackTrace);}

        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
        }
               

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        
        #endregion
    }
}
