﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Microsoft.VisualBasic;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;
using System.Text.RegularExpressions;

using Outlook = Microsoft.Office.Interop.Outlook;
using Office = Microsoft.Office.Core;

namespace DragDrapWatcher_AddIn
{
    public partial class ThisAddIn
    {
        #region Global Variables
        public Outlook.Rules GlobalRules = null;
        public clsSendNotif Error_Sender = null;
        #endregion

        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {   
            Outlook._NameSpace outNS = null;
            SuperMailFolder folderToWrap = null;

            try
            {
                Error_Sender = new clsSendNotif();
                Outlook.Application application = this.Application;
                //Get the MAPI namespace
                outNS = application.GetNamespace("MAPI");
                //Get UserName
                string profileName = outNS.CurrentUser.Name;

                //DRAG & DROP WILL BE CREATED HERE
                Outlook.Folders folders = outNS.Folders;
                foreach (Outlook.Folder fldr in folders)
                    folderToWrap = new SuperMailFolder(fldr, profileName);                   
            }
            catch (Exception ex)
            {Error_Sender.SendNotification(ex.Message + ex.StackTrace);}

        }
        
        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
        }
        //Start the Ribbon & Context Menu
        protected override Microsoft.Office.Core.IRibbonExtensibility CreateRibbonExtensibilityObject()
        {
            return new Ribbon();
        }

        #region Rules Manipulation
        public Outlook.Rule fnFindRuleByName(string rule_name)
        {
            if (this.GlobalRules == null)
                this.GlobalRules = Globals.ThisAddIn.Application.Session.DefaultStore.GetRules();
         
            Outlook.Rule rule = null;
            if (this.GlobalRules != null && !string.IsNullOrEmpty(rule_name))
            {
                foreach (Outlook.Rule r in this.GlobalRules)
                {
                    if (r.Name.ToLower() == rule_name.ToLower())
                    {
                        rule = r;
                        break;
                    }
                }              
            }
            return rule;
        }

        public bool fnAddEmailToRule(string rule_name,string email_address,Outlook.MAPIFolder target_folder)
        {
            Outlook.Rule rule = fnFindRuleByName(rule_name);
            bool ok_added = false;
            bool email_exist = false;
            string recipient_address;
               
            //CREATE NEW RULE
            if(rule==null){
                rule = this.GlobalRules.Create(rule_name, Outlook.OlRuleType.olRuleReceive);
                rule.Actions.MoveToFolder.Folder = (target_folder);
                rule.Actions.MoveToFolder.Enabled = true;
                ok_added = true;
            }
            //CHECK IF THE EMAIL ADDRESS IS ALREADY ADDED
            if(rule.Conditions.From.Recipients.Count >0){
                foreach (Outlook.Recipient _recipient in rule.Conditions.From.Recipients)
                {
                    recipient_address = _recipient.Address;
                    if (!Error_Sender.IsValidEmailAdd(recipient_address))
                    {
                        if (_recipient.AddressEntry.GetExchangeUser() != null)
                            recipient_address = _recipient.AddressEntry.GetExchangeUser().PrimarySmtpAddress.Trim().ToLower();
                        else if (Error_Sender.IsValidEmailAdd(_recipient.Name))
                            recipient_address = _recipient.Name.Trim().ToLower();
                    }
                        

                    if (recipient_address.ToLower() == email_address.ToLower())
                    {
                        email_exist = true;
                        break;
                    }
                }
            }

            //ADD THE NON EXISTING EMAILADDRESS
            if (!email_exist)
            {                               
                rule.Conditions.From.Recipients.Add(email_address);
                rule.Conditions.From.Recipients.ResolveAll();
                rule.Conditions.From.Enabled = true;
                ok_added = true;
            }
            return ok_added;
        }

        public bool fnRemoveEmailFromRule(string rule_name, string email_address)
        {
            string recipient_address;
            bool ok_remove = false;
            Outlook.Rule src_rule = this.fnFindRuleByName(rule_name);

            if (src_rule != null)
            {
                foreach (Outlook.Recipient _recipient in src_rule.Conditions.From.Recipients)
                {
                    recipient_address = _recipient.Address;
                    if (!Error_Sender.IsValidEmailAdd(recipient_address))
                    {
                        if (_recipient.AddressEntry.GetExchangeUser() != null) 
                            recipient_address = _recipient.AddressEntry.GetExchangeUser().PrimarySmtpAddress.Trim().ToLower();
                        else if(Error_Sender.IsValidEmailAdd(_recipient.Name))
                            recipient_address = _recipient.Name.Trim().ToLower();                                                
                    }                        

                    if (recipient_address.ToLower() == email_address.ToLower())
                    {
                        _recipient.Delete();
                        _recipient.Resolve();
                        ok_remove = true;
                        break;
                    }
                }
            }
            if (src_rule != null)
            {
                if (src_rule.Conditions.From.Recipients.Count == 0)
                {
                    this.GlobalRules.Remove(rule_name);
                    ok_remove = true;
                }
            }
            return ok_remove;
        }
        #endregion
        
        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
            
        }
        
        #endregion
    }

    #region Error Notification Class
    public class clsSendNotif
    {
        private const string local_log_path = "C:\\FarCap_Outlook_AddIn\\Error.log";
        private const string Subject = "FarCap Outlook Add-In";

        public bool SendNotification(string str_message)
        {
            bool ok_sent = false;

            Outlook.MailItem mail = null;
            Outlook.Recipients mailRecipients = null;
            Outlook.Recipient mailRecipient = null;

            List<string> recipients = Split_Recipients(Properties.Settings.Default.Recipient);
            string ex_msg = "";
            try
            {
                if (recipients.Count > 0)
                {
                    mail = (Outlook.MailItem)Globals.ThisAddIn.Application.CreateItem(Outlook.OlItemType.olMailItem);
                    mail.Subject = Subject + " Error";
                    mail.Body = "An exception has occured in the code of add-in.";
                    mail.Body += "\n\n" + str_message;
                    mailRecipients = mail.Recipients;

                    foreach (string eadd in recipients)
                    {
                        mailRecipient = mailRecipients.Add(eadd);
                        mailRecipient.Resolve();
                    }
                    if (mailRecipient.Resolved)
                    {
                        ((Outlook._MailItem)mail).Send();
                        ok_sent = true;
                    }
                    else
                    {
                        ex_msg = "Unable to send the error notification";
                    }
                }
                else
                {
                    ex_msg = "No recipient.";
                }
            }
            catch (Exception ex)
            {
                ex_msg = ex.Message + ex.StackTrace;
            }
            finally
            {
                if (mailRecipient != null)
                    Marshal.ReleaseComObject(mailRecipient);
                if (mailRecipients != null)
                    Marshal.ReleaseComObject(mailRecipients);
                if (mail != null)
                    Marshal.ReleaseComObject(mail);
            }

            if (!ok_sent)
                WriteLog(ex_msg, str_message);

            return ok_sent;

        }

        public bool SendTestNotification(string str_message, string str_recipients)
        {
            bool ok_sent = false;

            Outlook.MailItem mail = null;
            Outlook.Recipients mailRecipients = null;
            Outlook.Recipient mailRecipient = null;

            List<string> recipients = Split_Recipients(str_recipients);
            string ex_msg = "";
            try
            {
                if (recipients.Count > 0)
                {
                    mail = (Outlook.MailItem)Globals.ThisAddIn.Application.CreateItem(Outlook.OlItemType.olMailItem);
                    mail.Subject = Subject + " Error";
                    mail.Body = "An exception has occured in the code of add-in.";
                    mail.Body += "\n\n" + str_message;
                    mailRecipients = mail.Recipients;
                    foreach (string eadd in recipients)
                    {
                        mailRecipient = mailRecipients.Add(eadd);
                        mailRecipient.Resolve();
                    }
                    if (mailRecipient.Resolved)
                    {
                        ((Outlook._MailItem)mail).Send();
                        ok_sent = true;
                    }
                    else
                    {
                        ex_msg = "Unable to send the error notification";
                    }
                }
                else
                {
                    ex_msg = "No recipient.";
                }
            }
            catch (Exception ex)
            {
                ex_msg = ex.Message + ex.StackTrace;
            }
            finally
            {
                if (mailRecipient != null)
                    Marshal.ReleaseComObject(mailRecipient);
                if (mailRecipients != null)
                    Marshal.ReleaseComObject(mailRecipients);
                if (mail != null)
                    Marshal.ReleaseComObject(mail);
            }

            if (!ok_sent)
                WriteLog(ex_msg, str_message);

            return ok_sent;
        }

        private void WriteLog(string ex_msg, string str_message)
        {

            StreamWriter writer = null;
            try
            {
                if (!Directory.Exists(Path.GetDirectoryName(local_log_path)))
                    Directory.CreateDirectory(Path.GetDirectoryName(local_log_path));

                writer = new StreamWriter(local_log_path, true);
                if (!string.IsNullOrWhiteSpace(ex_msg))
                {
                    writer.WriteLine("Unsend Notification Error: " + ex_msg);
                }
                writer.WriteLine("Timestamp: " + DateTime.Now.ToString());
                writer.WriteLine("Error: " + str_message);
                writer.WriteLine();
                writer.Close();
                writer.Dispose();
                writer = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to write log!\nException: " + ex.Message +
                    "\n\nMessage:" + str_message, "FarCap Outlook Add-in");
            }
            finally
            {
                if (writer != null)
                {
                    writer.Close();
                    writer.Dispose();
                }
            }
        }

        public bool IsValidEmailAdd(string email_add)
        {
            Regex regex = new Regex(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$",
             RegexOptions.CultureInvariant | RegexOptions.Singleline);

            if (string.IsNullOrWhiteSpace(email_add))
                return false;

            return regex.IsMatch(email_add.Trim());
        }

        private List<string> Split_Recipients(string str_recipients)
        {
            string[] sp = str_recipients.Split(new char[] { ';' });
            List<string> rec = new List<string>();

            foreach (string s1 in sp)
            {
                if (IsValidEmailAdd(s1))
                {
                    rec.Add(s1.Trim());
                }
            }
            return rec;
        }
    }
    #endregion

    #region ClassMailFolder object
    class SuperMailFolder
    {
        #region private variables
        Outlook.Folder _wrappedFolder;
        string _profileName;
        public List<SuperMailFolder> wrappedSubFolders = new List<SuperMailFolder>();
        string folderName = string.Empty;
        #endregion

        #region constructor
        internal SuperMailFolder(Outlook.Folder folder, string profileName)
        {
            try
            {
                //assign it to local private master
                _wrappedFolder = folder;
                folderName = folder.Name;
                _profileName = profileName;
                //assign event handlers for the folder
                _wrappedFolder.Items.ItemAdd += Items_ItemAdd;
                _wrappedFolder.BeforeItemMove += Before_ItemMoveListener;

                //Go through all the subfolders and wrap them as well
                foreach (Outlook.Folder tmpFolder in _wrappedFolder.Folders)
                {
                    SuperMailFolder tmpWrapFolder = new SuperMailFolder(tmpFolder, _profileName);
                    wrappedSubFolders.Add(tmpWrapFolder);
                    wrappedSubFolders.AddRange(tmpWrapFolder.wrappedSubFolders);
                }
            }
            catch (Exception ex)
            { Globals.ThisAddIn.Error_Sender.SendNotification(ex.Message + ex.StackTrace); }
        }
        #endregion

        private void Before_ItemMoveListener(object Item, Outlook.MAPIFolder TargetFolder, ref bool Cancel)
        {
            try
            {
                if (Item is Outlook.MailItem && TargetFolder != null)
                {
                    string src_rule_name = "";
                    string tar_rule_name = "";

                    bool ok_added = false;
                    bool ok_removed = false;

                    ///Outlook.Rules rules = null;
                    Outlook.MailItem oMsg = (Outlook.MailItem)Item;
                    Outlook.Folder src_folder = (Outlook.Folder)oMsg.Parent;

                    if (string.IsNullOrWhiteSpace(oMsg.SenderEmailAddress)) return;

                    //REMOVE RULE FROM SOURCE FOLDER
                    if (src_folder.Name.ToLower() != "inbox" &&
                            src_folder.Name.ToLower().StartsWith(Properties.Settings.Default.WatchFolder_Prefix.ToLower()))
                    {
                        src_rule_name = Properties.Settings.Default.RuleName_Prefix + src_folder.Name;
                        ok_removed = Globals.ThisAddIn.fnRemoveEmailFromRule(src_rule_name, oMsg.SenderEmailAddress);
                    }

                    //DESTINATION FOLDER
                    if (TargetFolder.Name.ToLower() != "inbox" &&
                            TargetFolder.Name.ToLower().StartsWith(Properties.Settings.Default.WatchFolder_Prefix.ToLower()))
                    {

                        tar_rule_name = Properties.Settings.Default.RuleName_Prefix + TargetFolder.Name;
                        ok_added = Globals.ThisAddIn.fnAddEmailToRule(tar_rule_name, oMsg.SenderEmailAddress, TargetFolder);
                    }

                    //Save rules
                    if (Globals.ThisAddIn.GlobalRules != null && (ok_added || ok_removed))
                        Globals.ThisAddIn.GlobalRules.Save(true);
                }
            }
            catch (Exception ex)
            {
                Globals.ThisAddIn.Error_Sender.SendNotification(ex.Message + ex.StackTrace);
            }
        }

        void Items_ItemRemove()
        {

        }

        #region Handler of addition item into a folder
        void Items_ItemAdd(object Item)
        {
            try
            {
                if (Item is Outlook.Folder)
                {
                    SuperMailFolder tmpWrapFolder = new SuperMailFolder((Outlook.Folder)Item, _profileName);
                    wrappedSubFolders.Add(tmpWrapFolder);
                    wrappedSubFolders.AddRange(tmpWrapFolder.wrappedSubFolders);
                }
            }
            catch (Exception ex)
            {
                Globals.ThisAddIn.Error_Sender.SendNotification(ex.Message + ex.StackTrace);
            }
        }

        #endregion
    }
    #endregion

}
