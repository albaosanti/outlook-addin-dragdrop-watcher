﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace DragDrapWatcher_AddIn
{
    public partial class frmSyncRule : Form
    {
        public Outlook.Folder parent_folder;
        public bool cancelled = false;

        public frmSyncRule()
        {
            InitializeComponent();
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            if (btnProcess.Text.ToLower() == "start")
            {
                btnProcess.Text = "Stop";
                cancelled = false;
                lblStatus.Text = "Started..";
                bgwProcess.RunWorkerAsync();
            }
            else
            {
                if (MessageBox.Show("Are you sure to STOP the running process?", "Confirm Exit",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == System.Windows.Forms.DialogResult.Yes)
                {
                    cancelled = true;
                    btnProcess.Text = "Stopping..";
                    btnProcess.Enabled = false;
                }
            }
        }

        private void bgwProcess_DoWork(object sender, DoWorkEventArgs e)
        {

            string sender_address;
            string rule_name;
            int progress = 0;
            int success = 0;
            int total_item = 0;
            Outlook.MailItem mail;
            try
            {
                rule_name = Properties.Settings.Default.RuleName_Prefix + parent_folder.Name;
                total_item = parent_folder.Items.Count;
                for (int i = 1; i <= total_item; i++)
                {
                    if (cancelled) break;
                    progress = Convert.ToInt32((( Convert.ToDouble(i) / Convert.ToDouble(total_item)) * 100));
                    bgwProcess.ReportProgress(progress, "Processing " + (i) + "/" + parent_folder.Items.Count);                   
                    if (parent_folder.Items[i] is Outlook.MailItem)
                    {
                        mail = (Outlook.MailItem)parent_folder.Items[i];
                        sender_address = mail.SenderEmailAddress;
                        if (!Globals.ThisAddIn.Error_Sender.IsValidEmailAdd(sender_address))
                        {
                              if(mail.Sender.GetExchangeUser()!=null)
                                  sender_address = mail.Sender.GetExchangeUser().PrimarySmtpAddress;
                              else if(Globals.ThisAddIn.Error_Sender.IsValidEmailAdd(mail.SenderName))
                                  sender_address = mail.SenderName;
                              else 
                                  sender_address="";

                        }

                        if (sender_address != "")
                        {
                            if (Globals.ThisAddIn.fnAddEmailToRule(rule_name, sender_address, parent_folder))
                            {
                                success += 1;
                            }
                        }
                                
                    }
                }
                if (success > 0) Globals.ThisAddIn.GlobalRules.Save(true);
            }
            catch (Exception ex)
            {
                Globals.ThisAddIn.Error_Sender.SendNotification(ex.Message + ex.StackTrace);
            }
        }

        private void bgwProcess_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            if (e.ProgressPercentage >= 1 && e.ProgressPercentage <= 100)
            {
                progressBar1.Value = e.ProgressPercentage;

            }
            lblStatus.Text =  e.UserState.ToString(); 
        }

        private void bgwProcess_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            this.Text = "Done";
            lblStatus.Text = "Done.";
            btnProcess.Text = "Start";
            btnProcess.Enabled = true;
            this.Close();
        }

        private void frmSyncRule_Load(object sender, EventArgs e)
        {
            cancelled = false;
            lblFolderName.Text = parent_folder.Name;
            btnProcess.PerformClick();
        }
    }
}
